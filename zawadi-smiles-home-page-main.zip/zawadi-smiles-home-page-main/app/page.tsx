"use client";

import React, { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
// import "tailwindcss/tailwind.css";

type NavbarProps = {
  scrollToSection: (sectionId: string) => void;
};

const Navbar: React.FC<NavbarProps> = ({ scrollToSection }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Top Section */}
      <div className="bg-[#006D5B] text-white py-2 px-4 flex flex-col md:flex md:flex-row justify-between items-center">
        <div>
          <a href="mailto:info@zawadismiles.com" className="text-sm flex">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-mail"
            >
              <rect width="20" height="16" x="2" y="4" rx="2" />
              <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
            </svg>
            &nbsp;info@zawadismiles.com
          </a>
        </div>
        <div className="flex space-x-4">
          <Link href="/about" className="text-sm">
            Facebook Icon
          </Link>
          <Link href="/contact" className="text-sm">
            Instagram Icon
          </Link>
          <Link href="/contact" className="text-sm">
            X Icon
          </Link>
        </div>
      </div>

      {/* Border Separator */}
      <div className="border-b border-white"></div>

      {/* Bottom Section - Main Navigation */}
      <nav className="bg-[#006D5B] px-4 shadow-md text-white">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="">
            <Link href="/">
              <Image
                src={"/assets/WhiteOnBlackZSLogo.png"}
                alt="Zawadi Smiles Logo"
                width={100}
                height={100}
              />
            </Link>
          </div>

          {/* Hamburger Menu Button (for mobile) */}
          <button
            className="md:hidden text-gray-800"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Navigation Links (Desktop) */}
          <div className="hidden md:flex space-x-6">
            <Link
              href="#our-work"
              className="hover:text-blue-600"
              onClick={() => scrollToSection("our-work")}
            >
              Our Work
            </Link>
            <Link
              href="#community-health"
              className="hover:text-blue-600"
              onClick={() => scrollToSection("community-health")}
            >
              Community Health
            </Link>
            <Link
              href="#immunization"
              className="hover:text-blue-600"
              onClick={() => scrollToSection("immunization")}
            >
              Immunization
            </Link>
            <Link
              href="#donate"
              className="hover:text-blue-600"
              onClick={() => scrollToSection("donate")}
            >
              Donate
            </Link>
            <Link
              href="#communicable-diseases"
              className="hover:text-blue-600"
              onClick={() => scrollToSection("communicable-diseases")}
            >
              Communicable Diseases
            </Link>
            <Link
              href="#zs-ehrs"
              className="hover:text-blue-600"
              onClick={() => scrollToSection("zs-ehrs")}
            >
              ZS-EHRS
            </Link>
          </div>
        </div>

        {/* Collapsible Menu (Mobile) */}
        {isMenuOpen && (
          <div className="flex flex-col mt-4 space-y-2 md:hidden">
            <Link
              href="#our-work"
              className="hover:text-blue-600"
              onClick={() => {
                scrollToSection("our-work");
                setIsMenuOpen(false);
              }}
            >
              Our Work
            </Link>
            <Link
              href="#community-health"
              className="hover:text-blue-600"
              onClick={() => {
                scrollToSection("community-health");
                setIsMenuOpen(false);
              }}
            >
              Community Health
            </Link>
            <Link
              href="#immunization"
              className="hover:text-blue-600"
              onClick={() => {
                scrollToSection("immunization");
                setIsMenuOpen(false);
              }}
            >
              Immunization
            </Link>
            <Link
              href="#donate"
              className="hover:text-blue-600"
              onClick={() => {
                scrollToSection("donate");
                setIsMenuOpen(false);
              }}
            >
              Donate
            </Link>
            <Link
              href="#communicable-diseases"
              className="hover:text-blue-600"
              onClick={() => {
                scrollToSection("communicable-diseases");
                setIsMenuOpen(false);
              }}
            >
              Communicable Diseases
            </Link>
            <Link
              href="#zs-ehrs"
              className="hover:text-blue-600"
              onClick={() => {
                scrollToSection("zs-ehrs");
                setIsMenuOpen(false);
              }}
            >
              ZS-EHRS
            </Link>
          </div>
        )}
      </nav>
    </header>
  );
};

const Home = () => {
  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll("section");
      const scrollPosition = window.scrollY + 1000;

      sections.forEach((section) => {
        if (section instanceof HTMLElement) {
          if (
            section.offsetTop <= scrollPosition &&
            section.offsetTop + section.offsetHeight > scrollPosition
          ) {
          }
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      const yOffset = -100; // Adjust for navbar height
      const yPosition =
        section.getBoundingClientRect().top + window.scrollY + yOffset;
      window.scrollTo({ top: yPosition, behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar scrollToSection={scrollToSection} />

      <main className="flex flex-col items-center w-5/6 mx-auto max-w-screen-lg">
        <section id="our-work" className="pt-28 py-20 px-4 bg-gray-100">
          <h2 className="text-3xl font-bold mb-4">Our Work</h2>
          <p>
            Details about the work Zawadi Smiles does to support communities.
          </p>
        </section>

        <section id="community-health" className="pt-28 py-20 px-4 bg-white">
          <h2 className="text-3xl font-bold mb-4">Community Health</h2>
          <p>Community health initiatives and projects by Zawadi Smiles.</p>
        </section>

        <section id="immunization" className="pt-28 py-20 px-4 bg-gray-100">
          <h2 className="text-3xl font-bold mb-4">Immunization</h2>
          <p>
            Information about the immunization programs offered by Zawadi
            Smiles.
          </p>
        </section>

        <section id="donate" className="pt-28 py-20 px-4 bg-white">
          <h2 className="text-3xl font-bold mb-4">Donate</h2>
          <p>
            Support Zawadi Smiles by donating to help improve healthcare
            services.
          </p>
        </section>
        <section
          id="communicable-diseases"
          className="pt-28 py-20 px-4 bg-gray-100"
        >
          <h2 className="text-3xl font-bold mb-4">Communicable Diseases</h2>
          <p>
            Efforts by Zawadi Smiles to combat communicable diseases in the
            community.
          </p>
        </section>
        <section id="zs-ehrs" className="pt-28 py-20 px-4 bg-white">
          <h2 className="text-3xl font-bold mb-4">
            Zawadi Smiles' Electronic Health Record System
          </h2>
          <p>
            Zawadi Smiles' Electronic Health Record System (ZS-EHRS) leveraging
            web3 and crypto technologies to provide secure and accessible health
            records.
          </p>
        </section>
      </main>

      <footer className="bg-black text-white py-10 px-4">
        <div className="container mx-auto">
          <div className="flex-col space-x-4 space-y-4 md:flex md:flex-row border-b border-white">
            <div className="flex-initial flex justify-center md:flex-none">
              <Image
                src={"/assets/WhiteOnBlackZSLogo.png"}
                alt="Zawadi Smiles Logo"
                width={200}
                height={200}
              />
            </div>
            <div className="">
              <h3 className="text-lg font-bold">About Us</h3>
              <p className="mb-2">
                Zawadi Smiles is a Christian humanitarian organisation founded
                in 2024, based in Nairobi, Kenya and committed to strengthening
                primary healthcare for underserved communities in Kenya and
                across Africa.
              </p>
              <p className="mb-2">
                Our approach centres on three pillars: reducing morbidity and
                mortality, providing care at your doorstep, and leveraging
                electronic health records (EHR) to enhance service delivery.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-2">Programs</h3>
              <ul className="flex flex-col mb-2 md:flex">
                <li>
                  <Link href="#community-health" className="hover:underline">
                    Community Health
                  </Link>
                </li>
                <li>
                  <Link href="#immunization" className="hover:underline">
                    Immunization
                  </Link>
                </li>
                <li>
                  <Link
                    href="#communicable-diseases"
                    className="hover:underline"
                  >
                    Communicable Diseases
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="text-center mt-2">
            <p>
              Copyright 2024. Built by{" "}
              <Link
                href={"https://caesius.agency"}
                rel="noopener noreferrer"
                target="_blank"
              >
                Caesius Agency
              </Link>
              .
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
